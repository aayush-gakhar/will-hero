package game.willhero;

public class GreenOrc extends Orc {

    public GreenOrc(double x) {
        super(x,-200,"assets/orcGreen.png");
    }

    public GreenOrc(double x,double y) {
        super(x,y,"assets/orcGreen.png");
    }

}
