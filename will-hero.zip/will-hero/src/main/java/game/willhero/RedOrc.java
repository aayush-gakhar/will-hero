package game.willhero;

public class RedOrc extends Orc {
    public RedOrc(double x) {
        super(x,-200,"assets/orcRed.png");
    }

    public RedOrc(double x,double y) {
        super(x,y,"assets/orcRed.png");
    }
}
